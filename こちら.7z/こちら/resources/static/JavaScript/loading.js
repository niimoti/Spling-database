// window.onload = function() {
//     const wrap = document.getElementById('load_top');
//     wrap.classList.add('completed');
// }

function loaded(){
    document.getElementById("loading").classList.remove("active");
}

window.addEventListener("load" , function () {
    setTimeout(loaded, 1500)
})

setTimeout(loaded, 5000)

var timer = 0;
var currentWidth = window.innerWidth;
$(window).resize(function(){
    if (currentWidth == window.innerWidth) {
        return;
    }
    if (timer > 0) {
        clearTimeout(timer);
    }

    timer = setTimeout(function () {
        location.reload();
    }, 200);

});
package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "questionnaire")
@NoArgsConstructor
@AllArgsConstructor
public class Questionnaire {

    @Id
    @Column(name = "answerdeadline")
    private String answerdeadline;

    @Column(name = "distributiondate")
    private String distributiondate;

}

package com.example.demo.repository;

import com.example.demo.model.Explanation;
import com.example.demo.model.InformationSessionModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InformationSessionRepository extends JpaRepository<InformationSessionModel, Long> {

    InformationSessionModel findAllById(Long id);
    List<InformationSessionModel> findBykNameContaining(String kName);
    List<InformationSessionModel> findByDeadlineGreaterThanEqualOrderByEcpdatetimeDesc(String datetime);

    void deleteByTempfile(String fileName);
}

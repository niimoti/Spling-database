package com.example.demo.controller;

import com.example.demo.java.ExString;
import com.example.demo.model.InformationSessionModel;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class TeacherController {

    //この権限は見るだけ^～竿竹^～
    //生徒情報・生徒の詳しい情報とかね
    private final StudentRepository studentRepository;
    private final ReserveRepository reserveRepository;
    private final UserRepository userRepository;
    private final QualificationRepository qualificationRepository;
    private final InformationSessionRepository informationSessionRepository;
    private final TeacherRepository teacherRepository;

    public TeacherController(StudentRepository studentRepository, ReserveRepository reserveRepository, UserRepository userRepository, QualificationRepository qualificationRepository, InformationSessionRepository informationSessionRepository, TeacherRepository teacherRepository) {
        this.studentRepository = studentRepository;
        this.reserveRepository = reserveRepository;
        this.userRepository = userRepository;
        this.qualificationRepository = qualificationRepository;
        this.informationSessionRepository = informationSessionRepository;
        this.teacherRepository = teacherRepository;
    }

    //学生一覧表示
    @GetMapping("/teacher/searchByStudent")
    public String searchByStudentPrint(
            Model model
    ) {
        model.addAttribute("studentAll",studentRepository.findAll());
        return "/teacher/searchByStudent";
    }

    @GetMapping("/teacher/ascOrDesc")
    public String ascOrDescPrint(
            Model model,
            @RequestParam String sort
    ) {
        System.out.println(sort);
        switch (sort) {
            case "numAsc":
                model.addAttribute("studentAll",studentRepository.findByOrderByUsernameAsc());
                break;
            case "numDesc":
                model.addAttribute("studentAll",studentRepository.findByOrderByUsernameDesc());
                break;
            case "workAsc":
                model.addAttribute("studentAll",studentRepository.findByOrderByIndustryAsc());
                break;
            case "workDesc":
                model.addAttribute("studentAll",studentRepository.findByOrderByIndustryDesc());
                break;
            case "classAsc":
                model.addAttribute("studentAll",studentRepository.findByOrderByClassNameAsc());
                break;
            case "classDesc":
                model.addAttribute("studentAll",studentRepository.findByOrderByClassNameDesc());
                break;
            default:
                model.addAttribute("studentAll",studentRepository.findAll());
                break;
        }
        return "/teacher/searchByStudent";
    }

    @RequestMapping("/teacher/studentDetail")
    public String studentDetailPrint(
            Model model,
            @RequestParam String username
    ) {
        //reserveテーブル（説明会予約）を配列で0~*件取得
        //user(ユーザ情報)を一件取得
        //student(ユーザ情報)で一件取得
        //qualification(資格情報)を配列で0~*件取得
        model.addAttribute("reserve",reserveRepository.findByUsername(username));
        model.addAttribute("user",userRepository.findByUsername(username));
        model.addAttribute("studentHello",studentRepository.findByUsername(username));
        model.addAttribute("qualification", qualificationRepository.findByUsername(username));
        return "/teacher/studentDetail";
    }

    @GetMapping("/teacher/ISSearch")
    public String ketsuANA(
            @ModelAttribute InformationSessionModel informationSessionModel,
            Model model
    ) {
        model.addAttribute("ketsu", informationSessionRepository.findAll());
        return "teacher/ISSearch";
    }

    @GetMapping("/teacher/ISSearchByCompany")
    public String CompanySearch(
            Model model,
            @RequestParam String kName
    ) {
        try {
            model.addAttribute("ketsu",informationSessionRepository.findBykNameContaining(kName));
        } catch (Exception e) {
            model.addAttribute("ketsu",informationSessionRepository.findAll());
        }
        model.addAttribute("ketsu",informationSessionRepository.findBykNameContaining(kName));
        return "teacher/ISSearch";
    }

    @GetMapping("/teacher/ISReserve")
    public String ISReserve(
            @RequestParam(required = false) String company,
            Authentication loginUser,
            Model model
    ) {
        model.addAttribute("user", userRepository.findAll());
        model.addAttribute("com", informationSessionRepository.findAll());
        model.addAttribute("res", reserveRepository.findAll());
        model.addAttribute("company", company);
        model.addAttribute("stu", studentRepository.findByClassName(teacherRepository.getByUsername(loginUser.getName()).getTclass()));
        return "/teacher/ISReserve";
    }

    @PostMapping("/teacher/ISprint")
    public String ISPrint(
            Model model,
            @RequestParam String isId,
            @ModelAttribute InformationSessionModel informationSessionModel
    ) {
        ExString exString = new ExString();
        model.addAttribute("filePath2",informationSessionRepository.findAllById(exString.getLong(isId)));
        return "teacher/ISprint";
    }
}
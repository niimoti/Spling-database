package com.example.demo.java;

import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;

@Component
public class MailSample {
    private final MailSender mailSender;

    public MailSample(MailSender mailSender) {
        this.mailSender = mailSender;

        this.sendMail("","");
    }

    public void sendMail(String a,String b) {

        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setFrom("test@test.jp"); // 送信元メールアドレス
        mailMessage.setTo(a);
        mailMessage.setSubject("企業説明会のおしらせです");//タイトル
        mailMessage.setText(b);//本文

        try {
            mailSender.send(mailMessage);
        } catch (MailException e) {
            // TODO: エラー処理
        }
    }
}
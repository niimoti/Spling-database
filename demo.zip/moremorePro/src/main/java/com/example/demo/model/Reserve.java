package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "reserve")
@NoArgsConstructor
@AllArgsConstructor
@IdClass(value = MultiplePrimary.ReservePrimary.class)
public class Reserve {

    @Id
    @Column(name = "username")
    private String username;

    @Id
    @Column(name = "companyname")
    private String companyname;

    @Column(name = "resdatetime")
    private String resdatetime;

}

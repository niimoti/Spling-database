package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "companys")
@NoArgsConstructor
@AllArgsConstructor
public class Companys {

    //企業名
    @Id
    @Column(name = "companysname")
    private String companysname;

    //業種
    @Column(name = "industry")
    private String industry;

}

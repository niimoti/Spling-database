package com.example.demo.java;

public class Path {

    public String securityPath(String setPath){

        return setPath
                .replace("[ROLE_","")
                .replace("]","").toLowerCase();
    }

}

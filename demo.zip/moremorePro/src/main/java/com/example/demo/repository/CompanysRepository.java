package com.example.demo.repository;

import com.example.demo.model.Companys;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CompanysRepository extends JpaRepository<Companys, String> {

    @Override
    Optional<Companys> findById(String companysname);

//    Companys findByCompany(String companysname);できねえ
    List<Companys> findByCompanysnameContaining(String companyName);

}

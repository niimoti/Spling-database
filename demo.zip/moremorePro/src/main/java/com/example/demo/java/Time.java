package com.example.demo.java;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Time {
    public String NowTime() {
        LocalDateTime nowDateTime = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        String nowtime = nowDateTime.format( format );
        return nowtime;
    }

    public String ConvertTime(String time) {
        StringBuilder str = new StringBuilder(time.substring(0, 4));
        for (int i = 2; i < 6; i++) {
            if (i < 4) str.append('-');
            else if (i == 4) str.append(' ');
            else str.append(":");
            str.append(time, i * 2, i * 2 + 2);
        }
        return new String(str);
    }
}

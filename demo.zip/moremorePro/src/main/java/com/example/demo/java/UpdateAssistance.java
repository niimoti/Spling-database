package com.example.demo.java;

import com.example.demo.model.InformationSessionModel;
import com.example.demo.model.SiteUser;
import com.example.demo.repository.InformationSessionRepository;

import java.util.Optional;

//ただただSQLのupdateをアシストするためのクラス
//InformationSessionModel型に更新内容を入れて渡すだけ

public class UpdateAssistance {

    InformationSessionRepository informationSessionRepository;

    public InformationSessionModel updateISM(
            String id,
            String day,
            String place,
            String deadline,
            String kName,
            String industry,
            String contents,
            String URL,
            String explanation,
            String tempfile
            ) {
        ExString exString = new ExString();
        InformationSessionModel model = new InformationSessionModel();

        model.setId(exString.getLong(id));
        model.setDay(day);
        model.setPlace(place);
        model.setDeadline(deadline);
        model.setKName(kName);
        model.setIndustry(industry);
        model.setContents(contents);
        model.setURL(URL);
        model.setExplanation(explanation);
        model.setTempfile(tempfile);

        System.out.println(model.getId());
        System.out.println(model.getContents());
        System.out.println(model.getDay());
        System.out.println(model.getDeadline());
        System.out.println(model.getExplanation());
        System.out.println(model.getIndustry());
        System.out.println(model.getKName());
        System.out.println(model.getPlace());
        System.out.println(model.getURL());
        System.out.println(model.getTempfile());

        return model;

    }

    //ユーザ情報のロールを変更する
    public SiteUser deleteStudent(
            String username,
            String password,
            String name,
            String email
    ) {
        SiteUser siteUser = new SiteUser();
        String role = "EXPIREDSTUDENT";
        siteUser.setUsername(username);
        siteUser.setPassword(password);
        siteUser.setName(name);
        siteUser.setEmail(email);
        siteUser.setRole(role);
        siteUser.setTeacher(false);
        siteUser.setSpTeacher(false);
        siteUser.setStudent(false);
        siteUser.setExpiredStudent(true);

        return siteUser;
    }

}

package com.example.demo.model;

import lombok.Data;

@Data
public class QuestionJson {

    private  String company;
    private  String progress;
}

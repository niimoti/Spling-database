package com.example.demo.repository;

import com.example.demo.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {

    //sort by student
    List<Student> findByOrderByUsernameAsc();
    List<Student> findByOrderByUsernameDesc();
    List<Student> findByOrderByIndustryAsc();
    List<Student> findByOrderByIndustryDesc();
    List<Student> findByOrderByClassNameAsc();
    List<Student> findByOrderByClassNameDesc();
    Student findByUsername(String username);
    List<Student> findByClassName(String className);
    List<Student> findByClassNameOrderByUsernameAsc(String className);
    List<Student> findByClassNameOrderByUsernameDesc(String className);
    List<Student> findByClassNameOrderByIndustryAsc(String className);
    List<Student> findByClassNameOrderByIndustryDesc(String className);
    List<Student> findByClassNameOrderByClassNameAsc(String className);
    List<Student> findByClassNameOrderByClassNameDesc(String className);
}

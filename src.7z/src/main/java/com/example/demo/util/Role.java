package com.example.demo.util;

public enum Role {
    SPTEACHER,TEACHER,STUDENT,EXPIREDSTUDENT
}

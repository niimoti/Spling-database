package com.example.demo.model;

import lombok.*;

import javax.persistence.*;

@Data
@Entity
@Table(name = "information_session")
@NoArgsConstructor
@AllArgsConstructor
public class InformationSessionModel {

    @Id
    @GeneratedValue
    @Column(name = "id")
    private Long id;

    @Column(name = "k_name")
    private String kName;

    @Column(name = "industry")
    private String industry;

    @Column(name = "day")
    private String day;

    @Column(name = "contents")
    private String contents;

    @Column(name = "place")
    private String place;

    @Column(name = "deadline")
    private String deadline;

    @Column(name = "url")
    private String URL;

    @Column(name = "explanation")
    private String explanation;

    @Column(name = "tempfile")
    private String tempfile;

    @Column(name = "ecpdatetime")
    private String ecpdatetime;
}

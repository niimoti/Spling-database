package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Setter
@Getter
@Entity
@Table(name = "qualification")
@NoArgsConstructor
@AllArgsConstructor
@IdClass(value = MultiplePrimary.QualificationPrimary.class)
public class Qualification {

    @Id
    @Column(name = "username")
    private String username;

    @Id
    @Column(name = "qualification")
    private String qualification;

}

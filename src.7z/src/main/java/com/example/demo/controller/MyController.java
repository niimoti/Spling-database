package com.example.demo.controller;

import com.example.demo.java.Path;
import com.example.demo.java.Time;
import com.example.demo.model.Answer;
import com.example.demo.model.SiteUser;
import com.example.demo.repository.*;
import com.example.demo.util.Role;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@RequiredArgsConstructor
@Controller
public class MyController {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final ExplanationRepository explanationRepository;
    private final InformationSessionRepository informationSessionRepository;
    private final AnswerRepository answerRepository;
    private final StudentRepository studentRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final ReserveRepository reserveRepository;
    private final TeacherRepository teacherRepository;

    //---------------------ログイン画面・未ログイン時の画面

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    //---------------------ログインした時の遷移先画面
    @GetMapping("/")
    public String showList(
            Authentication loginUser,
            Model model
            ) {

        System.out.println("loginnでけた");

        Path path = new Path();
        Time time = new Time();
//        studentに行く場合。
        model.addAttribute("username", loginUser.getName()); //username
//        model.addAttribute("role", loginUser.getAuthorities()); //role
        model.addAttribute("nowtime", time.NowTime());
        model.addAttribute("userrole", userRepository.findByUsername(loginUser.getName()).getRole());
//        model.addAttribute("explanation", explanationRepository.findAll());
        model.addAttribute("explanation", informationSessionRepository.findAll());
        model.addAttribute("answer", answerRepository.findAll());
        model.addAttribute("student", studentRepository.findAll());
        model.addAttribute("questionnaire",questionnaireRepository.findAll());
        model.addAttribute("reserve", reserveRepository.findAll());
//        model.addAttribute("resdata", explanationRepository.findByReservedeadlineGreaterThanEqualOrderByExpdatetimeDesc(time.ConvertTime("20210410000000")));
        model.addAttribute("resdata", informationSessionRepository.findByDeadlineGreaterThanEqualOrderByEcpdatetimeDesc(time.ConvertTime("20210410000000")));
        model.addAttribute("user", userRepository.findAll());
        model.addAttribute("teaclass", teacherRepository.getByUsername(loginUser.getName()));
        //各roleのメニュー画面に遷移
        return path.securityPath(String.valueOf(loginUser.getAuthorities())) + "/menu";
    }

//    @GetMapping("/spTeacher/page")
//    public String page() {
//        return "spTMenu";
//    }

    //-------------------ユーザ新規作成-----------------------

    @GetMapping("/register")
    public String register(@ModelAttribute("user") SiteUser user) {
        return "register";
    }

    @PostMapping("/register")
    public String process(@ModelAttribute("user") SiteUser user,
                          BindingResult result) {
        if (result.hasErrors()){
            return "register";
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));

        if (user.isSpTeacher()) {
            user.setRole(Role.SPTEACHER.name());
        } else if (user.isTeacher()) {
            user.setRole(Role.TEACHER.name());
        } else if (user.isStudent()) {
            user.setRole(Role.STUDENT.name());
        } else {
            user.setRole(Role.EXPIREDSTUDENT.name());
        }
        userRepository.save(user);

        return "redirect:/login?register";

    }

    //--------------------------------------------------------

}

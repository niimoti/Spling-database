let num = 0
const nextbutton = '<button onclick="indicate(4)">次へ</button>',
    backbutton = '<button onclick="indicate(-4)">前へ</button>'

$(function (){indicate(0)});

function indicate(n) {
    console.log('にいもとのてぃんてぃん')
    alert('Line 9 of NewInfo.js: Look at console.')
    let str = '<ul>'
    const table = []
    num += n;
    switch (role) {
        case 'STUDENT':
            for (let i = 0; i < 4; i++) {
                if (new1.length > i + num) str += '<li>企業名：' + new1[i + num] + '<br>' + '説明会日：' + new2[i + num] + '<br>' + '予約締切日：' + new3[i + num] + '<br><button type="submit" name="company" value="' + new1[i + num] + '">' + new1[i + num] + 'の予約へ</button></li>'
                else str += '<li>これ以上新着情報はありません</li>'
            }
            str += num !== 0 ? backbutton:''
            str += new1.length > num + 4 ? nextbutton:''
            break
        case 'TEACHER':
            for (let i = 0; rcom.length > i; i++) {
                for (let j = 0; stuname.length > j; j++) {
                    if ((stuclass[j] === teacher) && (rstu[i] === stuname[j])) {
                        let sel = []
                        sel.push(rstu[i])
                        sel.push(rdate[i])
                        sel.push(rcom[i])
                        table.push(sel)
                    }
                }
            }
            cretabe(table)
            break
        case 'SPTEACHER':
            for (let i = 0; rcom.length > i; i++) {
                let sel = []
                sel.push(rstu[i])
                sel.push(rdate[i])
                sel.push(rcom[i])
                table.push(sel)
            }
            cretabe(table)
            break
    }
    document.getElementById('newInfo').innerHTML = str

    function cretabe(table) {
        for (let i = 0; i < 4; i++) {
            if (table.length > i + num) {
                for (let j = 0; usid.length > j; j++) {
                    if (table[i][0] === usid[j]) {
                        str += '<li>生徒名：' + usname[j] + '<br>予約日時：' + table[i][1] + '<br>企業名：' + table[i][2]
                        for (let k = 0; new1.length > k; k++) if (table[i][2] === new1[k]) str += '<br>説明会日時：' + new2[k] + '<br><button type="submit" name="company" value="' + table[i][2] + '">' + table[i][2] + 'の予約一覧へ</button></li>'
                    }
                }
            } else {
                str += '<li>これ以上新着情報はありません</li>'
            }
        }
        str += num !== 0 ? backbutton:''
        str += rcom.length > num + 4 ? nextbutton:''
    }
}
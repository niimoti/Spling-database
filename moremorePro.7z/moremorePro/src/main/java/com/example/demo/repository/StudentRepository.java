package com.example.demo.repository;

import com.example.demo.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {

    //sort by student
    List<Student> findByOrderByUsernameAsc();
    List<Student> findByOrderByUsernameDesc();
    List<Student> findByOrderByIndustryAsc();
    List<Student> findByOrderByIndustryDesc();
    List<Student> findByOrderByClassNameAsc();
    List<Student> findByOrderByClassNameDesc();
    List<Student> findByUsername(String username);
    List<Student> findByClassName(String className);
}

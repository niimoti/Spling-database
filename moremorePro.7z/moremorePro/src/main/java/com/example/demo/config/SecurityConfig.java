package com.example.demo.config;

import com.example.demo.util.Role;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@RequiredArgsConstructor
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final UserDetailsService userDetailsService;

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/js/**", "/css/**", "/img/**","/webjars/**", "/PDF/**","file:PDF/**");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                //全員がアクセスできる場所の指定,増やせ
                .antMatchers("/login","/register","/h2-console/**","file:PDF/**","/PDF/**").permitAll()
                //アクセス許可
                .antMatchers("/spteacher/**","/PDF/**").hasRole(Role.SPTEACHER.name()) //就職講師のみアクセス可
                .antMatchers("/teacher/**").hasRole(Role.TEACHER.name()) //教師のみアクセス可
                .antMatchers("/student/**").hasRole(Role.STUDENT.name()) //学生のみアクセス可能
                .antMatchers("/exstudent/**").hasRole(Role.EXPIREDSTUDENT.name())//期限切れ学生のみアクセス可能
                .anyRequest().authenticated() //それ以外は認証していない場合アクセス不許可
                .and()
                .formLogin().loginPage("/login").defaultSuccessUrl("/")
                .and()
                .logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .and()
                .rememberMe();
        http.csrf().ignoringAntMatchers("/h2-console/**"); //データベースコンソールを使えるようにする　以下一行も同様
        http.headers().frameOptions().disable();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //userDetailsServiceを使用してDBからユーザを参照できるようにする。
        auth.userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder());
    }

}

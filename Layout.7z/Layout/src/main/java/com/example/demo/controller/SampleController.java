package com.example.demo.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SampleController {

    //一番最初に出るところ
    @RequestMapping("/")
    public String inx() {
        return "login";
    }
}
